var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});



router.get('/result', (req, res, next) {

    let query = req.query.search;

    request("https://api.themoviedb.org/3/search/movie?api_key=d805aea65d0b0bca681d38545de83be3d&query=" + query, (error, response, body) => {
        if (error) {
            console.log(error);
        } else {
            let data = JSON.parse(body);
            res.render('result', { data: data, querySearch: query });
        }
    })
});

module.exports = router;